/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package while07;

/**
 *
 * @author auerovap
 */
public class While07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int b = 6;
        do {
            System.out.println(b);
            b++;
        } while (b <= 12);
    }
}
