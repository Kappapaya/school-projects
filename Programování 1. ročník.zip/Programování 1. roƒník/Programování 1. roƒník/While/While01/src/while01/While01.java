/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package while01;

/**
 *
 * @author auerovap
 */
public class While01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 0;
        while (i < 10) {
            {
                System.out.println(i);
                i++;
            }
        }
    }
}
